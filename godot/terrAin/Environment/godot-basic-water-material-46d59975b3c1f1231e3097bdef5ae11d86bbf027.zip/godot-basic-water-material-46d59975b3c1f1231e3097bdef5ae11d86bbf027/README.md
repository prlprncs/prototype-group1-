# Basic Water Material

A basic water material for the Godot Engine 3.x.

#### Video/How To:
https://youtu.be/jbYrpKWTlpw

![Image](assets/maujoe.basic_water_material/screenshots/basic_water_material_1.jpg)

## License

All parts of this project that are not copyrighted or licensed by someone else are released free under the MIT License - see the LICENSE.md file for details.
